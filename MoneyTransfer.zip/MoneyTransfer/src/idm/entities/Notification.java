package idm.entities;

public class Notification {

}
