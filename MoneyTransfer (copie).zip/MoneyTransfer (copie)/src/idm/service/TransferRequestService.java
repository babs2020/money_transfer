package idm.service;

public interface TransferRequestService {

	public void transfer(double amount,String description,String debit, String credit);
}
