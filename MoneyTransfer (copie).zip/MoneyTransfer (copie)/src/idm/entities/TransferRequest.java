package idm.entities;

public class TransferRequest {

}
